
    async function getPokemonDetails() {
        try {
            const pokemonName = document.getElementById('pokemonName').value.toLowerCase();
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
            const data = await response.json();

            const pokemonAbilities = data.abilities.map(ability => ability.ability.name).join(', ');
            const pokemonTypes = data.types.map(type => type.type.name).join(', ');

            const speciesResponse = await fetch(data.species.url);
            const speciesData = await speciesResponse.json();
            const pokemonSpecies = speciesData.name;

            const pokemonDetails = `
            <h2>${data.name}</h2>
            <p><strong>Abilities:</strong> ${pokemonAbilities}</p>
            <p><strong>Type(s):</strong> ${pokemonTypes}</p>
            <p><strong>Species:</strong> ${pokemonSpecies}</p>
            <img src="${data.sprites.front_default}" alt="${data.name}"/>
        `;

            document.getElementById('pokemonDetails').innerHTML = pokemonDetails;
        } catch (error) {
            console.error('Details not found', error);
        }
    }

    async function getPokemonList() { 
        async function fetchPokemonList() {
            try {
                const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=100');
                const data = await response.json();
                return data.results;
            } catch (error) {
                console.error('Error fetching Pok�mon list:', error);
                return [];
            }
        }

        async function fetchPokemonDetails(pokemonName) {
            try {
                const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
                const data = await response.json();
                return data;
            } catch (error) {
                console.error(`Error fetching details for ${pokemonName}:`, error);
                return null;
            }
        }

        async function populatePokemonList() {
            const pokemons = await fetchPokemonList();
            pokemons.forEach(pokemon => {
                const listItem = document.createElement('li');
                listItem.textContent = pokemon.name;
                listItem.addEventListener('click', async () => {
                    const details = await fetchPokemonDetails(pokemon.name);
                    if (details) {
                        const abilities = details.abilities.map(ability => ability.ability.name).join(', ');
                        const types = details.types.map(type => type.type.name).join(', ');
                        const imageUrl = details.sprites.front_default;

                        pokemonDetails.innerHTML = `
                            <h2>${details.name}</h2>
                            <p><strong>Abilities:</strong> ${abilities}</p>
                            <p><strong>Types:</strong> ${types}</p>
                            <img src="${imageUrl}" alt="${details.name}">
                        `;
                    } else {
                        pokemonDetails.innerHTML = '<p>Failed to fetch Pok�mon details.</p>';
                    }
                });
                pokemonList.appendChild(listItem);
            });
        }

        populatePokemonList();
    };
    async function filterPokemon() {
        const nameFilter = document.getElementById('nameFilter').value.toLowerCase();
        const abilityFilter = document.getElementById('abilityFilter').value.toLowerCase();
        const typeFilter = document.getElementById('typeFilter').value.toLowerCase();

        try {
            const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=100');
            const data = await response.json();


            const filteredPokemon = data.results.filter(pokemon => {
                return (nameFilter === '' || pokemon.name.includes(nameFilter)) &&
                    (abilityFilter === '' || pokemon.abilities.some(ability => ability.ability.name.includes(abilityFilter))) &&
                    (typeFilter === '' || pokemon.types.some(type => type.type.name.includes(typeFilter)));
            });


            const filteredPokemonList = document.getElementById('filteredPokemonList');
            filteredPokemonList.innerHTML = '';

            filteredPokemon.forEach(async pokemon => {
                const details = await fetchPokemonDetails(pokemon.name);
                if (details) {
                    const abilities = details.abilities.map(ability => ability.ability.name).join(', ');
                    const types = details.types.map(type => type.type.name).join(', ');
                    const imageUrl = details.sprites.front_default;

                    const listItem = document.createElement('li');
                    listItem.innerHTML = `<strong>Name:</strong> ${pokemon.name}<br>
                                          <strong>Abilities:</strong> ${abilities}<br>
                                          <strong>Types:</strong> ${types}<br>
                                          <img src="${imageUrl}" alt="${details.name}"><br><br>`;
                    filteredPokemonList.appendChild(listItem);
                }
            });
        } catch (error) {
            console.error('Error filtering Pok�mon:', error);
        }
    }

    async function fetchPokemonDetails(pokemonName) {
        try {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
            const data = await response.json();
            return data;
        } catch (error) {
            console.error(`Error fetching details for ${pokemonName}:`, error);
            return null;
        }
    }
    
    async function populateDropdowns() {
        try {
            const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=100');
            const data = await response.json();

            const nameDropdown = document.getElementById('nameFilter');
            const abilityDropdown = document.getElementById('abilityFilter');
            const typeDropdown = document.getElementById('typeFilter');

            data.results.forEach(pokemon => {
                pokemon.name.forEach(name => {
                    const nameOption = document.createElement('option');
                    nameOption.text = pokemon.name;
                    nameDropdown.add(nameOption);
                });

                pokemon.abilities.forEach(ability => {
                    const abilityOption = document.createElement('option');
                    abilityOption.text = ability.ability.name;
                    abilityDropdown.add(abilityOption);
                });

                pokemon.types.forEach(type => {
                    const typeOption = document.createElement('option');
                    typeOption.text = type.type.name;
                    typeDropdown.add(typeOption);
                });
            });
        } catch (error) {
            console.error('Error populating dropdowns:', error);
        }
    }

    populateDropdowns();
    
    async function comparePokemon() {
        const pokemon1Name = document.getElementById('pokemon1').value;
        const pokemon2Name = document.getElementById('pokemon2').value;

        const pokemon1Details = await fetchPokemonDetails(pokemon1Name);
        const pokemon2Details = await fetchPokemonDetails(pokemon2Name);

        if (!pokemon1Details || !pokemon2Details) {
            console.error('Error fetching Pok�mon details');
            return;
        }

        let betterPokemon = null;
        
        if (pokemon1Details.base_experience > pokemon2Details.base_experience) {
            betterPokemon = pokemon1Details;
        } else if (pokemon1Details.base_experience < pokemon2Details.base_experience) {
            betterPokemon = pokemon2Details;
        }

        const comparisonResult = document.getElementById('comparisonResult');
        comparisonResult.innerHTML = '';

        if (betterPokemon) {
            comparisonResult.innerHTML = `
                <h2>Better Pokemon: ${betterPokemon.name}</h2>
                <p>Base Experience: ${betterPokemon.base_experience}</p>
                <p>Abilities: ${betterPokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
                <p>Types: ${betterPokemon.types.map(type => type.type.name).join(', ')}</p>
            `;
        } else {
            comparisonResult.innerHTML = '<p>Pok�mon are equal in strength.</p>';
        }
    }

    async function fetchPokemonDetails(pokemonName) {
        try {
            const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
            const data = await response.json();
            return data;
        } catch (error) {
            console.error(`Error fetching details for ${pokemonName}:`, error);
            return null;
        }
    }

    async function populateDropdowns() {
        try {
            const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=100');
            const data = await response.json();

            const pokemon1Dropdown = document.getElementById('pokemon1');
            const pokemon2Dropdown = document.getElementById('pokemon2');

            data.results.forEach(pokemon => {
                const option1 = document.createElement('option');
                option1.value = pokemon.name;
                option1.text = pokemon.name;
                pokemon1Dropdown.add(option1);

                const option2 = document.createElement('option');
                option2.value = pokemon.name;
                option2.text = pokemon.name;
                pokemon2Dropdown.add(option2);
            });
        } catch (error) {
            console.error('Error populating dropdowns:', error);
        }
    }

    populateDropdowns();